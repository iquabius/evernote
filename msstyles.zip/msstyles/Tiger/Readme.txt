Tiger visual style for WindowsXP

This theme is based on Mac OSX 10.4 Tiger by Apple
Package contains Tiger Normal, Blue and Graphite all with Normal and Compact StartMenus and Apple and WinFlag Startbutton, three different font sizes (Lucida Grande 8, Tahoma 8 and Arial - 8), Wallpapers and alternatives StartButtons.

UPDATE 1 (v1.1)
- New Taskbar Tray
- Fixed Photoshop Bug

UPDATE 2 (v1.1.1)
- Fixed Compact StartMenu
- Added alternatives Startbuttons

Update 3 (v1.1.2)
- Added two msstyle without the search image in the tray
- Changed colors and icons in the shellstyle


----


www.studiotwentyeight.com

Copyright � 2002 - 2004, StudioTwentyEight
